{
    Item : [
        {
            category: "Top Stories",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=topnews"
        },
        {
            category: "India",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=india"
        },
        {
            category: "World",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=world"
        },
        {
            category: "NRI",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=nri"
        },
        {
            category: "Business",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=business"
        },
        {
            category: "Cricket",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=cricket"
        },
        {
            category: "Sports",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=sports"
        },
        {
            category: "Science",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=science"
        },
        {
            category: "Environment",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=environment"
        },
        {
            category: "Tech",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=tech"
        },
        {
            category: "Education",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=education"
        },
        {
            category: "Entertainment",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=entertainment"
        },
        {
            category: "Life & Style",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=lifenstyle"
        },
        {
            category: "City",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=city"
        },
        {
            category: "Movie Reviews",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=moviereviews"
        },
        {
            category: "TV",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=tv"
        },
        {
            category: "Events",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=events"
        },
        {
            category: "Photo",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=photo"
        },
        {
            category: "Video",
            url: "http://mfeeds.timesofindia.indiatimes.com/Feeds/urlList?category=video"
        }
    ]
}
